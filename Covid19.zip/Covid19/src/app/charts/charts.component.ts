import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';  
import { GoogleChartComponent } from 'angular-google-charts'; 
import { CoronaService } from '../shared/corona.service';

@Component({
  selector: 'app-charts',
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.css']
})
export class ChartsComponent implements OnInit {
  districtdata
  isAscendingSort: boolean = false;
  districtdata1
  constructor(private cs: CoronaService, ) { }

  ngOnInit(): void {
    this.cs.districtdata.subscribe(data => {

      let districtDataArray = [];
      Object.keys(data).forEach((key, index) => {
        districtDataArray.push(
          Object.assign({}, { stateName: key }, data[key])
        );
      });
      this.districtdata = districtDataArray
      console.log(data)
    })
}  



  title = 'googlechart';  
  type = 'LineChart';  
  data = [['Andaman Nicobar', 224 , 6223 , 5928],
  ['Andhra Pradesh', 170588 , 1206232 , 1027270],
  ['Arunachal Pradesh', 1633 , 19193 , 17501],
  ['Assam', 328033 , 272751 , 44078],
  ['Bihar', 25,11,25]
     
  ];  
  columnNames = [['string', 'Topping'],['number', 'active'],['number', 'confirmed'],['number', 'recovered']];    
  options = {   colors: ['blue', 'red', 'green', 'yellow'], is3D: true};  
  
  width = 500;  
  height = 300;  
  
}

