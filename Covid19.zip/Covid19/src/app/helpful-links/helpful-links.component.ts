import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-helpful-links',
  templateUrl: './helpful-links.component.html',
  styleUrls: ['./helpful-links.component.css']
})
export class HelpfulLinksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
